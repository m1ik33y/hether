const FLUX_PIN_ICON = '<path d="M12 17v5"/><path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 1-2-2H8a2 2 0 0 1 0 4 1 1 0 0 1 1 1v3.76z"/>';

let _fluxPinnedChannel = null;

const _fluxPinnedLoadTokens = {
  fluxRelayMessages: 0,
  fluxFsMessages: 0
};

let _fluxPinnedIndex = 0;

let _fluxPinnedItems = [];

function _fluxEnsurePinnedBar(messagesId) {
  const msgsEl = document.getElementById(messagesId);
  if (!msgsEl) {
    console.error("[FLUX][pinned] _fluxEnsurePinnedBar: no element with id", messagesId, "— render aborted, this is why nothing shows up");
    return null;
  }
  if (!msgsEl.parentElement) {
    console.error("[FLUX][pinned] _fluxEnsurePinnedBar:", messagesId, "has no parentElement (detached from DOM?) — render aborted");
    return null;
  }
  let bar = msgsEl.parentElement.querySelector(".flux-pinned-messages-bar");
  if (!bar) {
    bar = document.createElement("div");
    bar.className = "flux-pinned-messages-bar";
    bar.innerHTML = '<div class="flux-pinned-messages-inner"></div>';
    msgsEl.parentElement.insertBefore(bar, msgsEl);
    console.log("[FLUX][pinned] created new bar for", messagesId);
  } else {
    console.log("[FLUX][pinned] reused existing bar for", messagesId);
  }
  return bar;
}

function _fluxHidePinnedBar(messagesId) {
  const msgsEl = document.getElementById(messagesId);
  const bar = msgsEl?.parentElement?.querySelector(".flux-pinned-messages-bar");
  if (bar) bar.style.display = "none";
}

function _fluxClearPinnedFrontend() {
  _fluxPinnedLoadTokens.fluxRelayMessages++;
  _fluxPinnedLoadTokens.fluxFsMessages++;
  _fluxPinnedIndex = 0;
  _fluxPinnedItems = [];
  _fluxPinnedMessageIds.clear();
  _fluxHidePinnedBar("fluxRelayMessages");
  _fluxHidePinnedBar("fluxFsMessages");
}

function _fluxPinnedMessagePreview(msg) {
  const text = String(msg?.content || "").trim();
  if (text) return text;
  if (msg?.media_url) return msg.is_video ? "Video" : "Photo";
  return "Message";
}

async function _fluxGetPinnedMessages(convId) {
  if (!convId) return [];
  const {data: {user: user}} = await supabaseClient.auth.getUser();
  if (!user) return [];
  const isGroup = _fluxConvIsGroup(convId);
  const {data: pins, error: pinError} = await supabaseClient.from("pinned_messages").select("message_id,pinned_by,created_at").order("created_at", {
    ascending: true
  });
  if (pinError) {
    console.error("[FLUX][pinned] SELECT on pinned_messages failed — check RLS policy for this table:", pinError);
    return [];
  }
  console.log("[FLUX][pinned] pinned_messages rows fetched:", pins?.length ?? 0, pins);
  const ids = (pins || []).map(p => p.message_id).filter(Boolean);
  if (!ids.length) return [];
  const {data: msgs, error: msgError} = await supabaseClient.from("messages").select("*").in("id", ids);
  if (msgError) {
    console.error("[FLUX][pinned] SELECT on messages for pinned ids failed:", msgError);
    return [];
  }
  const byId = new Map((msgs || []).map(m => [ m.id, m ]));
  return (pins || []).map(p => {
    const msg = byId.get(p.message_id);
    return msg ? {
      ...msg,
      _pinCreatedAt: p.created_at,
      _pinnedBy: p.pinned_by
    } : null;
  }).filter(msg => msg && _fluxMsgBelongsToConv(msg, convId, user.id, isGroup));
}

function _fluxPinnedVisibleMessagesElement() {
  const ids = [ "fluxRelayMessages", "fluxFsMessages" ];
  let fallback = null;
  for (const id of ids) {
    const el = document.getElementById(id);
    if (!el) continue;
    fallback ||= el;
    const cs = getComputedStyle(el);
    if (cs.display !== "none" && cs.visibility !== "hidden" && el.offsetParent !== null) return el;
  }
  return fallback;
}

async function _fluxLoadPinnedTargetMessage(messageId) {
  if (!messageId) return false;
  const alreadyThere = document.querySelector(`[data-msg-id="${CSS.escape(String(messageId))}"]`);
  if (alreadyThere) return true;
  const msgsEl = _fluxPinnedVisibleMessagesElement();
  if (!msgsEl) return false;
  const isDesktop = msgsEl.id === "fluxRelayMessages";
  const maxAttempts = 100;
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const found = msgsEl.querySelector(`[data-msg-id="${CSS.escape(String(messageId))}"]`);
    if (found) return true;
    const allLoaded = isDesktop ? fluxDesktopAllLoaded : fluxMobileAllLoaded;
    const loading = isDesktop ? fluxDesktopLoadingMore : fluxMobileLoadingMore;
    if (allLoaded) break;
    if (loading) {
      await new Promise(r => setTimeout(r, 60));
      continue;
    }
    if (isDesktop) await loadMoreMessagesDesktop(); else await loadMoreMessagesMobile();
    await new Promise(r => setTimeout(r, 20));
  }
  return !!msgsEl.querySelector(`[data-msg-id="${CSS.escape(String(messageId))}"]`);
}

async function _fluxJumpToPinnedMessage(messageId) {
  if (!messageId) return;
  let target = document.querySelector(`[data-msg-id="${CSS.escape(String(messageId))}"]`);
  if (!target) {
    const loaded = await _fluxLoadPinnedTargetMessage(messageId);
    if (!loaded) return;
    target = document.querySelector(`[data-msg-id="${CSS.escape(String(messageId))}"]`);
  }
  if (!target) return;
  target.scrollIntoView({
    behavior: "smooth",
    block: "center"
  });
  target.classList.remove("flux-search-jump-highlight");
  void target.offsetWidth;
  target.classList.add("flux-search-jump-highlight");
}

function _fluxRenderPinnedMessages(convId, pins, messagesId) {
  const bar = _fluxEnsurePinnedBar(messagesId);
  if (!bar) return;
  const inner = bar.querySelector(".flux-pinned-messages-inner");
  if (!inner) {
    console.error("[FLUX][pinned] bar exists but is missing .flux-pinned-messages-inner — markup got corrupted somewhere, render aborted");
    return;
  }
  _fluxPinnedItems = Array.isArray(pins) ? pins : [];
  _fluxPinnedIndex = Math.max(0, Math.min(_fluxPinnedIndex, _fluxPinnedItems.length - 1));
  _fluxPinnedMessageIds.clear();
  _fluxPinnedItems.forEach(msg => _fluxPinnedMessageIds.add(msg.id));
  inner.innerHTML = "";
  bar.querySelector(".flux-pinned-card-count")?.remove();
  bar.querySelector(".flux-pinned-unpin")?.remove();
  bar.querySelector(".flux-pinned-next")?.remove();
  if (!_fluxPinnedItems.length) {
    bar.style.display = "none";
    console.log("[FLUX][pinned] no pinned items — bar hidden", {
      convId: convId,
      messagesId: messagesId
    });
    return;
  }
  bar.style.display = "flex";
  const msg = _fluxPinnedItems[_fluxPinnedIndex];
  const card = document.createElement("button");
  card.type = "button";
  card.className = "flux-pinned-card";
  card.title = "Jump to pinned message";
  card.innerHTML = `\n    <span class="flux-pinned-card-icon"><svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-pin-icon lucide-pin"><path d="M12 17v5"/><path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z"/></svg></span>\n    <span class="flux-pinned-card-copy">\n      <span class="flux-pinned-card-text">${escHtml(_fluxPinnedMessagePreview(msg))}</span>\n    </span>`;
  card.onclick = () => _fluxJumpToPinnedMessage(msg.id);
  inner.appendChild(card);
  const count = document.createElement("span");
  count.className = "flux-pinned-card-count";
  count.textContent = `${_fluxPinnedIndex + 1}/${_fluxPinnedItems.length}`;
  bar.appendChild(count);
  const unpin = document.createElement("button");
  unpin.type = "button";
  unpin.className = "flux-pinned-unpin";
  unpin.title = "Unpin message";
  unpin.setAttribute("aria-label", "Unpin message");
  unpin.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-pin-off-icon lucide-pin-off"><path d="M12 17v5"/><path d="M15 9.34V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H7.89"/><path d="m2 2 20 20"/><path d="M9 9v1.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h11"/></svg>';
  unpin.onclick = async e => {
    e.preventDefault();
    e.stopPropagation();
    await toggleFluxMessagePin(msg.id);
  };
  bar.appendChild(unpin);
  if (_fluxPinnedItems.length > 1) {
    const next = document.createElement("button");
    next.type = "button";
    next.className = "flux-pinned-next";
    next.title = "Next pinned message";
    next.setAttribute("aria-label", "Next pinned message");
    next.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>';
    next.onclick = e => {
      e.preventDefault();
      e.stopPropagation();
      _fluxPinnedIndex = (_fluxPinnedIndex + 1) % _fluxPinnedItems.length;
      _fluxRenderPinnedMessages(convId, _fluxPinnedItems, messagesId);
    };
    bar.appendChild(next);
  }
  requestAnimationFrame(() => {
    const cs = getComputedStyle(bar);
    const rect = bar.getBoundingClientRect();
    console.log("[FLUX][pinned] post-render bar state", {
      convId: convId,
      messagesId: messagesId,
      isConnected: bar.isConnected,
      inlineDisplay: bar.style.display,
      computedDisplay: cs.display,
      computedVisibility: cs.visibility,
      rect: {
        width: rect.width,
        height: rect.height,
        top: rect.top,
        left: rect.left
      },
      offsetParentIsNull: bar.offsetParent === null
    });
  });
}

async function loadFluxPinnedMessages(convId, messagesId) {
  const token = ++_fluxPinnedLoadTokens[messagesId];
  console.log("[FLUX][pinned] loadFluxPinnedMessages start", {
    convId: convId,
    messagesId: messagesId,
    token: token
  });
  const pins = await _fluxGetPinnedMessages(convId);
  if (token !== _fluxPinnedLoadTokens[messagesId]) {
    console.warn("[FLUX][pinned] load aborted — a newer load for this same view was started before this one finished", {
      convId: convId,
      messagesId: messagesId,
      token: token,
      currentToken: _fluxPinnedLoadTokens[messagesId]
    });
    return;
  }
  if (activeFluxId !== convId) {
    console.warn("[FLUX][pinned] load aborted — active conversation changed", {
      convId: convId,
      activeFluxId: activeFluxId
    });
    return;
  }
  console.log("[FLUX][pinned] rendering", {
    convId: convId,
    messagesId: messagesId,
    count: pins.length
  });
  _fluxRenderPinnedMessages(convId, pins, messagesId);
}

async function toggleFluxMessagePin(msgId) {
  if (!msgId || !activeFluxId) {
    console.warn("[FLUX][pinned] toggle aborted — missing msgId or activeFluxId", {
      msgId: msgId,
      activeFluxId: activeFluxId
    });
    return;
  }
  const {data: {user: user}, error: userError} = await supabaseClient.auth.getUser();
  if (userError) {
    console.error("[FLUX][pinned] auth.getUser() failed", userError);
  }
  if (!user) {
    console.warn("[FLUX][pinned] toggle aborted — no authenticated user");
    return;
  }
  const {data: existing, error: checkError} = await supabaseClient.from("pinned_messages").select("message_id").eq("message_id", msgId).maybeSingle();
  if (checkError) {
    console.error("[FLUX][pinned] could not check pin state", checkError);
    alert("Could not check message pin state: " + checkError.message);
    return;
  }
  if (existing) {
    const {error: error} = await supabaseClient.from("pinned_messages").delete().eq("message_id", msgId);
    if (error) {
      console.error("[FLUX][pinned] unpin failed", error);
      alert("Could not unpin message: " + error.message);
      return;
    }
    console.log("[FLUX][pinned] unpinned", {
      msgId: msgId
    });
  } else {
    const {error: error} = await supabaseClient.from("pinned_messages").insert({
      message_id: msgId,
      pinned_by: user.id
    });
    if (error) {
      console.error("[FLUX][pinned] pin insert failed", error);
      if (/maximum|3 pinned|three pinned|too many/i.test(error.message || "")) {
        showFluxErrorToast?.("You can pin upto 3 elements");
      } else alert("Could not pin message: " + error.message);
      return;
    }
    console.log("[FLUX][pinned] pinned", {
      msgId: msgId
    });
  }
  _fluxPinnedIndex = 0;
  await loadFluxPinnedMessages(activeFluxId, "fluxRelayMessages");
  await loadFluxPinnedMessages(activeFluxId, "fluxFsMessages");
}

function _fluxSubscribePinnedMessages(convId) {
  if (_fluxPinnedChannel) {
    try {
      supabaseClient.removeChannel(_fluxPinnedChannel);
    } catch (e) {
      console.error("[FLUX][pinned] removeChannel threw", e);
    }
    _fluxPinnedChannel = null;
  }
  if (!convId) return;
  let debounceTimer = null;
  const channelName = `flux-pinned:${convId}:${Math.random().toString(36).slice(2)}`;
  const channel = supabaseClient.channel(channelName).on("postgres_changes", {
    event: "*",
    schema: "public",
    table: "pinned_messages"
  }, payload => {
    console.log("[FLUX][pinned] postgres_changes event received", {
      convId: convId,
      activeFluxId: activeFluxId,
      eventType: payload?.eventType,
      payload: payload
    });
    if (activeFluxId !== convId) {
      console.warn("[FLUX][pinned] ignoring event — conversation no longer active", {
        convId: convId,
        activeFluxId: activeFluxId
      });
      return;
    }
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      _fluxPinnedIndex = 0;
      loadFluxPinnedMessages(convId, "fluxRelayMessages");
      loadFluxPinnedMessages(convId, "fluxFsMessages");
    }, 150);
  }).subscribe((status, err) => {
    if (status === "SUBSCRIBED") {
      console.log("[FLUX][pinned] realtime channel subscribed", {
        convId: convId,
        channelName: channelName
      });
    } else if (status === "CHANNEL_ERROR" || status === "TIMED_OUT" || status === "CLOSED") {
      console.error("[FLUX][pinned] realtime channel failed", {
        convId: convId,
        channelName: channelName,
        status: status,
        err: err
      });
    } else {
      console.log("[FLUX][pinned] realtime channel status", {
        convId: convId,
        channelName: channelName,
        status: status
      });
    }
  });
  _fluxPinnedChannel = channel;
}

function _fluxCategoryOf(contactId) {
  return fluxCategories.get(contactId) || "primary";
}

function _fluxMutedOf(contactId) {
  return fluxMuted.get(contactId) === true;
}

function _fluxPinnedOf(contactId) {
  return fluxPinned.get(contactId) === true;
}

function _fluxArchivedOf(contactId) {
  return fluxArchived.get(contactId) === true;
}

function _updateUnarchiveBtnVisibility(id) {
  const archived = id ? _fluxArchivedOf(id) : false;
  const desktopBtn = document.getElementById("fluxUnarchiveBtn");
  const fsBtn = document.getElementById("fluxFsUnarchiveBtn");
  if (desktopBtn) desktopBtn.style.display = archived ? "flex" : "none";
  if (fsBtn) fsBtn.style.display = archived ? "flex" : "none";
}

function _updateGroupMenuBtnVisibility(id) {
  const hasChat = !!id;
  const desktopBtn = document.getElementById("fluxHeaderMoreBtn");
  const mobileBtn = document.getElementById("fluxFsHeaderMoreBtn");
  if (desktopBtn) desktopBtn.style.setProperty("display", hasChat ? "flex" : "none", "important");
  if (mobileBtn) mobileBtn.style.setProperty("display", hasChat ? "flex" : "none", "important");
  const desktopSearchBtn = document.getElementById("fluxHeaderSearchBtn");
  const mobileSearchBtn = document.getElementById("fluxFsHeaderSearchBtn");
  if (desktopSearchBtn) desktopSearchBtn.style.setProperty("display", hasChat ? "flex" : "none", "important");
  if (mobileSearchBtn) mobileSearchBtn.style.setProperty("display", hasChat ? "flex" : "none", "important");
  _updateGroupHeaderMuteVisibility(id);
}

function _setGroupMuteIcon(btn, muted) {
  if (!btn) return;
  const icon = btn.querySelector("svg");
  if (!icon) return;
  icon.innerHTML = muted ? '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>' : '<path d="M8.7 3A6 6 0 0 1 18 8c0 2.1.8 3.9 1.6 5.2"/><path d="M17 17H3s3-2 3-9c0-.7.1-1.4.3-2"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/><path d="m2 2 20 20"/>';
  const label = muted ? "Unmute group" : "Mute group";
  btn.title = label;
  btn.setAttribute("aria-label", label);
}

function _setFluxHeaderClearIcon(button, isGroup) {
  if (!button) return;
  const icon = button.querySelector("svg");
  if (!icon) return;
  icon.setAttribute("xmlns", "http://www.w3.org/2000/svg");
  icon.setAttribute("width", "24");
  icon.setAttribute("height", "24");
  icon.setAttribute("viewBox", "0 0 24 24");
  icon.setAttribute("fill", "none");
  icon.setAttribute("stroke", "currentColor");
  icon.setAttribute("stroke-width", "2");
  icon.setAttribute("stroke-linecap", "round");
  icon.setAttribute("stroke-linejoin", "round");
  icon.removeAttribute("class");
  icon.innerHTML = '<path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z"/><line x1="15" x2="9" y1="9" y2="15"/><line x1="9" x2="15" y1="9" y2="15"/>';
  button.title = "Clear all";
  button.setAttribute("aria-label", button.title);
}

function _updateGroupHeaderMuteVisibility(id) {
  const isGroup = id ? _fluxConvIsGroup(id) : false;
  const muted = isGroup && _fluxMutedOf(id);
  const desktopClear = document.getElementById("fluxDeleteRelayBtn");
  const mobileClear = document.getElementById("fluxFsDeleteRelayBtn");
  if (desktopClear) desktopClear.style.display = "inline-flex";
  if (mobileClear) mobileClear.style.display = "inline-flex";
  _setFluxHeaderClearIcon(desktopClear, false);
  _setFluxHeaderClearIcon(mobileClear, false);
  [ [ "fluxGroupMuteBtn", null ], [ "fluxFsGroupMuteBtn", null ] ].forEach(([btnId, dividerId]) => {
    const btn = document.getElementById(btnId);
    const divider = dividerId ? document.getElementById(dividerId) : null;
    if (btn) btn.style.display = isGroup ? "inline-flex" : "none";
    if (divider) divider.style.display = isGroup ? "block" : "none";
    if (btn) _setGroupMuteIcon(btn, muted);
  });
}

async function toggleActiveFluxGroupMute() {
  const id = activeFluxId;
  if (!id || !_fluxConvIsGroup(id)) return;
  await toggleFluxMute(id);
  _updateGroupHeaderMuteVisibility(id);
}

function confirmUnarchiveActive() {
  const id = activeFluxId;
  if (!id) return;
  showConfirm("Unarchive conversation?", "This chat will move back into your inbox and appear in your sidebar again.", "Unarchive", async () => {
    await toggleFluxArchive(id);
  });
}

async function toggleFluxArchive(contactId) {
  const wasArchived = _fluxArchivedOf(contactId);
  const newArchived = !wasArchived;
  if (newArchived && !_fluxHasArchiveSecret()) {
    openFluxArchiveSecretSetup(contactId);
    return;
  }
  await _archiveFluxContactNow(contactId);
}

async function _archiveFluxContactNow(contactId) {
  const ownerId = _fluxMyUserId || (await supabaseClient.auth.getUser()).data?.user?.id;
  if (!ownerId) return;
  const wasArchived = _fluxArchivedOf(contactId);
  const newArchived = !wasArchived;
  fluxArchived.set(contactId, newArchived);
  _updateUnarchiveBtnVisibility(activeFluxId);
  if (!newArchived) {
    const contactCategory = _fluxCategoryOf(contactId);
    if (fluxActiveTab !== "all" && fluxActiveTab !== contactCategory) switchFluxTab("all"); else buildFLUXConvList();
  } else {
    buildFLUXConvList();
  }
  const {error: error} = await supabaseClient.from("chat_categories").upsert({
    owner_id: ownerId,
    ..._fluxCatRowKey(contactId),
    category: _fluxCategoryOf(contactId),
    muted: _fluxMutedOf(contactId),
    pinned: _fluxPinnedOf(contactId),
    archived: newArchived,
    updated_at: (new Date).toISOString()
  }, {
    onConflict: _fluxCatOnConflict(contactId)
  });
  if (error) {
    console.error("Failed to update archive state:", error.message);
    fluxArchived.set(contactId, wasArchived);
    buildFLUXConvList();
    _updateUnarchiveBtnVisibility(activeFluxId);
    alert("Could not update archive setting: " + (error.message || "unknown error") + "\n\nPlease try again.");
  }
}

async function toggleFluxPin(contactId) {
  const ownerId = _fluxMyUserId || (await supabaseClient.auth.getUser()).data?.user?.id;
  if (!ownerId) return;
  if (_fluxArchivedOf(contactId)) return;
  const wasPinned = _fluxPinnedOf(contactId);
  const newPinned = !wasPinned;
  fluxPinned.set(contactId, newPinned);
  buildFLUXConvList();
  const {error: error} = await supabaseClient.from("chat_categories").upsert({
    owner_id: ownerId,
    ..._fluxCatRowKey(contactId),
    category: _fluxCategoryOf(contactId),
    muted: _fluxMutedOf(contactId),
    pinned: newPinned,
    updated_at: (new Date).toISOString()
  }, {
    onConflict: _fluxCatOnConflict(contactId)
  });
  if (error) {
    console.error("Failed to update pin state:", error.message);
    fluxPinned.set(contactId, wasPinned);
    buildFLUXConvList();
    alert("Could not update pin setting. Please try again.");
  }
}

async function toggleFluxMute(contactId) {
  const ownerId = _fluxMyUserId || (await supabaseClient.auth.getUser()).data?.user?.id;
  if (!ownerId) return;
  const wasMuted = _fluxMutedOf(contactId);
  const newMuted = !wasMuted;
  fluxMuted.set(contactId, newMuted);
  if (contactId === activeFluxId && _fluxConvIsGroup(contactId)) _updateGroupHeaderMuteVisibility(contactId);
  buildFLUXConvList();
  const {error: error} = await supabaseClient.from("chat_categories").upsert({
    owner_id: ownerId,
    ..._fluxCatRowKey(contactId),
    category: _fluxCategoryOf(contactId),
    muted: newMuted,
    pinned: _fluxPinnedOf(contactId),
    updated_at: (new Date).toISOString()
  }, {
    onConflict: _fluxCatOnConflict(contactId)
  });
  if (error) {
    console.error("Failed to update mute state:", error.message);
    fluxMuted.set(contactId, wasMuted);
    if (contactId === activeFluxId && _fluxConvIsGroup(contactId)) {
      _updateGroupHeaderMuteVisibility(contactId);
    }
    buildFLUXConvList();
  }
}

function _updateFluxTabCounts(withSentMessages) {
  const isUnreadConvo = c => c.unread && !(c.id === activeFluxId && _isRelayVisibleFor(c.id));
  const primaryCount = withSentMessages.filter(c => _fluxCategoryOf(c.id) === "primary" && isUnreadConvo(c)).length;
  const generalCount = withSentMessages.filter(c => _fluxCategoryOf(c.id) === "general" && isUnreadConvo(c)).length;
  [ [ "fluxPrimaryCount", primaryCount ], [ "fluxFsPrimaryCount", primaryCount ], [ "fluxGeneralCount", generalCount ], [ "fluxFsGeneralCount", generalCount ] ].forEach(([id, count]) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.textContent = count;
    el.dataset.zero = count === 0 ? "true" : "false";
  });
}

function switchFluxTab(tab, mode) {
  fluxActiveTab = tab;
  [ "fluxTabBar", "fluxFsTabBar" ].forEach(barId => {
    const bar = document.getElementById(barId);
    if (!bar) return;
    bar.querySelectorAll(".flux-tab-btn").forEach(btn => btn.classList.toggle("active", btn.dataset.tab === tab));
  });
  buildFLUXConvList();
}

function buildFLUXConvList() {
  const searchTerm = (_fluxSidebarSearchTerm || "").trim();
  const baseContacts = _fluxArchivedView ? fluxContacts.filter(c => _fluxArchivedOf(c.id)) : fluxContacts.filter(c => (c.sentByMe === true || _fluxPinnedOf(c.id)) && !_fluxArchivedOf(c.id));
  const withSentMessages = searchTerm ? _fluxArchivedView ? baseContacts.filter(c => (c.realName || c.name || "").toLowerCase().includes(searchTerm)) : fluxContacts.filter(c => !_fluxArchivedOf(c.id) && (c.realName || c.name || c.username || "").toLowerCase().includes(searchTerm)) : baseContacts;
  _updateFluxTabCounts(withSentMessages);
  const inActiveTab = fluxActiveTab === "all" ? withSentMessages : withSentMessages.filter(c => _fluxCategoryOf(c.id) === fluxActiveTab);
  const sorted = searchTerm ? [ ...inActiveTab ].sort((a, b) => (a.realName || a.name || "").localeCompare(b.realName || b.name || "")) : [ ...inActiveTab ].sort((a, b) => {
    const aPinned = _fluxPinnedOf(a.id) ? 1 : 0;
    const bPinned = _fluxPinnedOf(b.id) ? 1 : 0;
    if (bPinned !== aPinned) return bPinned - aPinned;
    const aUnread = a.unread && !(a.id === activeFluxId && _isRelayVisibleFor(a.id)) ? 1 : 0;
    const bUnread = b.unread && !(b.id === activeFluxId && _isRelayVisibleFor(b.id)) ? 1 : 0;
    if (bUnread !== aUnread) return bUnread - aUnread;
    return (b.lastMessageTs || 0) - (a.lastMessageTs || 0);
  });
  [ "fluxConvList", "fluxFsConvList" ].forEach(listId => {
    const list = document.getElementById(listId);
    if (!list) return;
    const isFsList = listId === "fluxFsConvList";
    list.innerHTML = "";
    if (!_fluxArchivedView && _fluxArchiveEntryUnlocked && !searchTerm) {
      list.appendChild(_buildFluxArchivedSidebarItem(isFsList));
    }
    if (sorted.length === 0) {
      if (!searchTerm && !_fluxArchivedView && _fluxArchiveEntryUnlocked) {
        return;
      }
      if (searchTerm) {
        list.innerHTML = `\n          <div class="flux-sidebar-no-user">\n            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-message-square-off-icon lucide-message-square-off"><path d="M19 19H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.7.7 0 0 1 2 21.286V5a2 2 0 0 1 1.184-1.826"/><path d="m2 2 20 20"/><path d="M8.656 3H20a2 2 0 0 1 2 2v11.344"/></svg>\n            <div>No user found</div>\n          </div>`;
        return;
      }
      const emptyMsg = withSentMessages.length === 0 ? _fluxArchivedView ? 'No archived chats.<br><span style="font-size:11.5px;opacity:0.7;">Archived chats will appear here.</span>' : 'No conversations yet.<br><span style="font-size:11.5px;opacity:0.7;">Search above to start relayting.</span>' : fluxActiveTab === "general" ? 'No general chats.<br><span style="font-size:11.5px;opacity:0.7;">Chats you move here will show up in this tab.</span>' : 'No primary chats.<br><span style="font-size:11.5px;opacity:0.7;">Check the General tab.</span>';
      list.innerHTML = `<div style="padding:28px 16px;text-align:center;font-size:12.5px;color:var(--text3);line-height:1.7;">${emptyMsg}</div>`;
      return;
    }
    sorted.forEach(c => {
      const item = document.createElement("div");
      item.className = "flux-conv-item" + (c.id === activeFluxId ? " active" : "");
      item.dataset.id = c.id;
      item.onclick = () => {
        _fluxArchiveEntryUnlocked = false;
        isFsList ? openFsRelay(c.id) : openDesktopRelay(c.id);
      };
      const lastMsg = _fluxRealtimeClearedConversations.has(c.id) ? null : c.lastMessage;
      const isUnread = c.unread && !(c.id === activeFluxId && _isRelayVisibleFor(c.id));
      const unreadCount = isUnread ? c.unreadCount || 0 : 0;
      let previewHtml = "";
      const senderPrefix = type => {
        if (type === "sent") return "You: ";
        return c.isGroup ? `${lastMsg?.senderName || c.name}: ` : "";
      };
      const mediaPreviewText = lastMsg && lastMsg.media && !(lastMsg.text || "").trim() ? `${senderPrefix(lastMsg.type)}sent an attachment` : null;
      if (isUnread && unreadCount >= 2) {
        const label = unreadCount > 4 ? "4+ new messages" : `${unreadCount} new messages`;
        previewHtml = `<div class="flux-conv-preview unread">${label}</div>`;
      } else if (isUnread && unreadCount === 1) {
        const msgText = mediaPreviewText || (lastMsg ? senderPrefix(lastMsg.type) + (lastMsg.text || "") : "");
        const truncated = msgText.length > 38 ? msgText.substring(0, 38) + "…" : msgText;
        previewHtml = `<div class="flux-conv-preview unread">${escHtml(truncated)}</div>`;
      } else {
        const msgText = mediaPreviewText || (lastMsg ? senderPrefix(lastMsg.type) + (lastMsg.text || "") : "");
        previewHtml = `<div class="flux-conv-preview">${escHtml(msgText)}</div>`;
      }
      let badgeHtml = isUnread ? '<div class="flux-unread-dot"></div>' : "";
      const isDualAvatar = c.isGroup && !c.avatarUrl;
      const avatarInner = c.avatarUrl ? `<img src="${c.avatarUrl}" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:50%;display:block;">` : c.isGroup ? buildDualAvatarHtml(c.memberAvatars) : DEFAULT_AVATAR_SVG;
      const avatarBg = c.avatarUrl ? "transparent" : c.isGroup ? "transparent" : "#e8e8ec";
      const avatarWrapStyle = isDualAvatar ? `background:${avatarBg};overflow:visible;border-radius:0;position:relative;` : `background:${avatarBg};overflow:hidden;position:relative;`;
      const isOnlineInList = onlineUsers.has(c.id);
      item.innerHTML = `\n        <div class="flux-conv-avatar-wrap">\n          <div class="flux-conv-avatar${isDualAvatar ? "" : " default-avatar"}" style="${avatarWrapStyle}">\n            ${avatarInner}\n          </div>\n          <div class="flux-conv-presence-dot${isOnlineInList ? " online" : ""}" data-presence-user="${c.id}"></div>\n        </div>\n        <div class="flux-conv-info">\n          <div class="flux-conv-toprow">\n            <div class="flux-conv-name">${escHtml(c.name)}</div>\n            <div class="flux-conv-time">${lastMsg ? lastMsg.time : ""}</div>\n          </div>\n          <div class="flux-conv-bottomrow">\n            ${previewHtml}\n            <div class="flux-conv-meta">\n              ${_fluxMutedOf(c.id) ? '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="var(--text3)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M8.7 3A6 6 0 0 1 18 8c0 2.1.8 3.9 1.6 5.2"/><path d="M17 17H3s3-2 3-9c0-.7.1-1.4.3-2"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/><path d="m2 2 20 20"/></svg>' : ""}\n              ${_fluxPinnedOf(c.id) ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--text3)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 17v5"/><path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z"/></svg>' : ""}\n              ${_fluxArchivedOf(c.id) ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--text3)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="5" rx="1"/><path d="M5 9v9a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V9"/><line x1="10" y1="13" x2="14" y2="13"/></svg>' : ""}\n              ${badgeHtml}\n            </div>\n          </div>\n        </div>\n        <button class="flux-conv-menu-btn" onclick="event.stopPropagation(); openFluxConvMenu(event, '${c.id}')">\n          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>\n        </button>\n      `;
      list.appendChild(item);
    });
  });
}

async function loadContacts() {
  const {data: {user: user}} = await supabaseClient.auth.getUser();
  if (!user) return;
  _fluxMyUserId = user.id;
  const [{data: data}, {data: nicknameRows}, {data: categoryRows}] = await Promise.all([ supabaseClient.from("profiles").select("id, username, display_name, avatar_url"), supabaseClient.from("nicknames").select("target_id, nickname").eq("setter_id", user.id), supabaseClient.from("chat_categories").select("contact_id, group_id, category, muted, pinned, archived").eq("owner_id", user.id) ]);
  if (!data) return;
  let groupRows = [];
  try {
    const {data: memberRows, error: memberErr} = await supabaseClient.from("flux_group_members").select("group_id").eq("user_id", user.id);
    if (memberErr) throw memberErr;
    const myGroupIds = [ ...new Set((memberRows || []).map(r => r.group_id)) ];
    if (myGroupIds.length) {
      const {data: groups, error: groupsError} = await supabaseClient.from("flux_groups").select("id, owner_id, name, name_is_custom, avatar_url, created_at, updated_at").in("id", myGroupIds).order("updated_at", {
        ascending: false
      });
      if (groupsError) throw groupsError;
      groupRows = groups || [];
    }
  } catch (e) {
    console.warn("[FLUX] group sidebar load failed:", e.message || e);
  }
  let groupIdsWithMyMessage = new Set;
  if (groupRows.length) {
    try {
      const {data: myGroupMessages, error: myGroupMessagesErr} = await supabaseClient.from("messages").select("group_id").eq("sender_id", user.id).in("group_id", groupRows.map(g => g.id));
      if (myGroupMessagesErr) throw myGroupMessagesErr;
      groupIdsWithMyMessage = new Set((myGroupMessages || []).map(m => m.group_id).filter(Boolean));
    } catch (e) {
      console.warn("[FLUX] group participation check failed:", e.message || e);
      groupIdsWithMyMessage = new Set;
    }
  }
  _fluxMyGroupIds = new Set(groupRows.map(g => g.id));
  fluxCategories.clear();
  fluxMuted.clear();
  fluxPinned.clear();
  fluxArchived.clear();
  (categoryRows || []).forEach(row => {
    const convId = row.contact_id || row.group_id;
    fluxCategories.set(convId, row.category);
    if (row.muted) fluxMuted.set(convId, true);
    if (row.pinned) fluxPinned.set(convId, true);
    if (row.archived) fluxArchived.set(convId, true);
  });
  const nicknameMap = {};
  (nicknameRows || []).forEach(row => {
    nicknameMap[row.target_id] = row.nickname;
  });
  const existingMap = new Map(fluxContacts.map(c => [ c.id, c ]));
  fluxContacts.length = 0;
  const colors = [ "linear-gradient(135deg,#5b6af0,#a855f7)", "linear-gradient(135deg,#f97316,#ec4899)", "linear-gradient(135deg,#22c55e,#06b6d4)", "linear-gradient(135deg,#6366f1,#0ea5e9)", "linear-gradient(135deg,#f43f5e,#8b5cf6)", "linear-gradient(135deg,#14b8a6,#06b6d4)" ];
  let colorIdx = 0;
  data.forEach(u => {
    if (u.id === user.id) return;
    const existing = existingMap.get(u.id);
    const rawUsername = u.username || "User";
    const realName = u.display_name || rawUsername;
    const nickname = nicknameMap[u.id] || null;
    const displayName = nickname || realName;
    fluxContacts.push({
      id: u.id,
      name: displayName,
      realName: realName,
      username: rawUsername,
      nickname: nickname,
      initials: displayName[0].toUpperCase(),
      avatarUrl: u.avatar_url || null,
      color: colors[colorIdx % colors.length],
      online: true,
      lastMessage: existing && !_fluxRealtimeClearedConversations.has(u.id) ? existing.lastMessage : null,
      lastMessageTs: existing && !_fluxRealtimeClearedConversations.has(u.id) ? existing.lastMessageTs : 0,
      unread: existing ? existing.unread : false,
      unreadCount: existing ? existing.unreadCount || 0 : 0,
      sentByMe: existing ? existing.sentByMe : false
    });
    colorIdx++;
  });
  const groupMembersByGroup = new Map;
  if (groupRows.length) {
    const {data: allMemberRows} = await supabaseClient.from("flux_group_members").select("group_id, user_id").in("group_id", groupRows.map(g => g.id));
    (allMemberRows || []).forEach(r => {
      if (!groupMembersByGroup.has(r.group_id)) groupMembersByGroup.set(r.group_id, []);
      groupMembersByGroup.get(r.group_id).push(r.user_id);
    });
  }
  const profileById = new Map((data || []).map(u => [ u.id, u ]));
  groupRows.forEach(g => {
    const existing = existingMap.get(g.id);
    const memberIds = groupMembersByGroup.get(g.id) || existing?.groupMembers || [];
    const pickedMemberIds = _fluxPickTwoGroupMembers(g.id, memberIds);
    const memberAvatars = pickedMemberIds.map(id => profileById.get(id)?.avatar_url || null);
    fluxContacts.push({
      id: g.id,
      groupId: g.id,
      isGroup: true,
      name: g.name || "Group",
      realName: g.name || "Group",
      username: g.name || "Group",
      nickname: null,
      initials: (g.name || "G").charAt(0).toUpperCase(),
      avatarUrl: g.avatar_url || null,
      memberAvatars: memberAvatars,
      color: null,
      online: false,
      ownerId: g.owner_id,
      nameIsCustom: g.name_is_custom === true,
      groupMembers: memberIds,
      groupMemberProfiles: Object.fromEntries(memberIds.map(id => {
        const profile = profileById.get(id);
        return [ id, {
          username: profile?.username || "",
          displayName: profile?.display_name || profile?.username || "User",
          avatarUrl: profile?.avatar_url || null
        } ];
      })),
      lastMessage: existing && !_fluxRealtimeClearedConversations.has(g.id) ? existing.lastMessage || null : null,
      lastMessageTs: existing && !_fluxRealtimeClearedConversations.has(g.id) ? existing.lastMessageTs || new Date(g.updated_at || g.created_at || 0).getTime() : 0,
      unread: existing?.unread || false,
      unreadCount: existing?.unreadCount || 0,
      sentByMe: groupIdsWithMyMessage.has(g.id),
      category: existing?.category || "primary"
    });
  });
  if (_inboxGroupingEnabled && _fluxHasArchiveSecret()) {
    const alreadySeen = new Set((categoryRows || []).map(row => row.contact_id || row.group_id));
    const newlyAddedGroups = groupRows.filter(g => g.owner_id !== user.id && !alreadySeen.has(g.id));
    if (newlyAddedGroups.length) {
      newlyAddedGroups.forEach(g => fluxArchived.set(g.id, true));
      supabaseClient.from("chat_categories").upsert(newlyAddedGroups.map(g => ({
        owner_id: user.id,
        contact_id: null,
        group_id: g.id,
        category: "primary",
        muted: false,
        pinned: false,
        archived: true,
        updated_at: (new Date).toISOString()
      })), {
        onConflict: "owner_id,group_id"
      }).then(({error: error}) => {
        if (error) console.warn("[FLUX] inbox grouping auto-archive failed:", error.message);
      });
    }
  }
  fluxContacts.forEach(c => {
    if (!c.isGroup) watchUserPresence(c.id);
  });
}

function showFluxEmptyState() {
  document.getElementById("fluxEmptyState").style.display = "flex";
  document.getElementById("fluxActiveRelayWrap").style.display = "none";
}

function showSkeletonMessages(container) {
  container.innerHTML = "";
  for (let i = 0; i < 5; i++) {
    const isSent = i % 2 === 0;
    const sk = document.createElement("div");
    sk.className = `flux-skeleton-msg${isSent ? " sent" : ""}`;
    if (!isSent) {
      const av = document.createElement("div");
      av.className = "flux-skeleton-av";
      sk.appendChild(av);
    }
    const bub = document.createElement("div");
    bub.className = "flux-skeleton-bubble";
    bub.style.width = 60 + Math.random() * 80 + "px";
    sk.appendChild(bub);
    container.appendChild(sk);
  }
}

async function openDesktopRelay(id) {
  _fluxArchiveEntryUnlocked = false;
  const contact = fluxContacts.find(c => c.id === id);
  if (!contact) return;
  contact.unread = false;
  contact.unreadCount = 0;
  _fluxActiveConvBgUnread = false;
  hideRemoteTyping();
  closeFluxChatSearch();
  document.getElementById("fluxProfileTab")?.classList.remove("show");
  activeFluxId = id;
  _fluxClearPinnedFrontend();
  _updateUnarchiveBtnVisibility(id);
  _updateGroupMenuBtnVisibility(id);
  _fluxSubscribePinnedMessages(id);
  const myToken = ++_fluxLoadToken;
  document.querySelectorAll("#fluxConvList .flux-conv-item").forEach(el => el.classList.toggle("active", el.dataset.id === id));
  document.getElementById("fluxTopbarName").textContent = contact.name;
  const usernameEl = document.getElementById("fluxTopbarUsername");
  if (usernameEl) {
    const raw = contact.username || contact.realName || contact.name;
    usernameEl.textContent = raw;
  }
  if (_fluxConvIsGroup(id)) {
    _fluxUpdateGroupHeaderMembers(id);
  }
  const av = document.getElementById("fluxTopbarAvatar");
  _fluxSetProfileTabAvatar(av, contact.avatarUrl, contact.isGroup && !contact.avatarUrl ? contact.memberAvatars : null);
  resetPresenceDots();
  updatePresenceDots();
  document.getElementById("fluxEmptyState").style.display = "none";
  document.getElementById("fluxActiveRelayWrap").style.display = "flex";
  const themePromise = loadRelayThemeFromSupabase(id);
  subscribeToRelayTheme(id);
  _startLoadBar("fluxRelayLoadBar", "fluxRelayLoadFill");
  _startLoadBar("fluxFsRelayLoadBar", "fluxFsRelayLoadFill");
  const fsMsgsEl = document.getElementById("fluxFsMessages");
  if (fsMsgsEl) fsMsgsEl.classList.add("flux-loading");
  const msgsEl = document.getElementById("fluxRelayMessages");
  if (msgsEl) msgsEl.classList.add("flux-loading");
  msgsEl.innerHTML = "";
  const {data: {user: user}} = await supabaseClient.auth.getUser();
  if (_fluxLoadToken !== myToken) return;
  if (user) await setupTypingChannel(user.id, id);
  if (_fluxLoadToken !== myToken) return;
  await themePromise;
  if (_fluxLoadToken !== myToken) return;
  await loadMessages(id, myToken);
  cancelReply();
  if (currentEditState) {
    currentEditState = null;
    document.getElementById("fluxEditBar")?.classList.remove("show");
    document.getElementById("fluxFsEditBar")?.classList.remove("show");
  }
  clearFluxStaging();
  document.getElementById("fluxInput").focus();
  await markConversationSeen(id);
}

async function openNicknamePanel() {
  if (!activeFluxId) return;
  const searchTab = document.getElementById("fluxSearchTab");
  const tab = document.getElementById("fluxProfileTab");
  const replacingSearchTab = !!searchTab?.classList.contains("show");
  if (replacingSearchTab) {
    searchTab.style.transition = "none";
    searchTab.classList.remove("show");
    void searchTab.offsetWidth;
    tab.style.transition = "none";
    tab.classList.add("show");
    void tab.offsetWidth;
    searchTab.style.transition = "";
    tab.style.transition = "";
  } else {
    tab.getBoundingClientRect();
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        tab.classList.add("show");
      });
    });
  }
  await loadNicknameSideTab(activeFluxId);
}

function closeNicknamePanel() {
  document.getElementById("fluxProfileTab").classList.remove("show");
}

async function loadNicknameSideTab(targetId) {
  if (!targetId) return;
  activeFluxProfileTarget = targetId;
  const {data: {user: user}} = await supabaseClient.auth.getUser();
  if (!user) return;
  if (_fluxConvIsGroup(targetId)) {
    await loadGroupInfoSideTab(targetId, user.id);
    return;
  }
  const titleEl = document.getElementById("fluxProfileTabTitle");
  if (titleEl) titleEl.textContent = "Profile";
  const mutualSection = document.getElementById("fluxMutualSection");
  if (mutualSection) mutualSection.style.display = "";
  const groupSection = document.getElementById("fluxGroupMembersSection");
  if (groupSection) groupSection.style.display = "none";
  hideGroupNameEditor();
  const groupNameEditBtn = document.getElementById("fluxGroupNameEditBtn");
  if (groupNameEditBtn) groupNameEditBtn.style.display = "none";
  const groupSettingsBtn = document.getElementById("fluxGroupSettingsBtn");
  if (groupSettingsBtn) groupSettingsBtn.style.display = "none";
  const groupNameRow = document.getElementById("fluxGroupNameRow");
  if (groupNameRow) groupNameRow.classList.remove("is-group");
  const closeBtn = document.getElementById("fluxProfileCloseBtn");
  if (closeBtn) closeBtn.style.display = "";
  const [{data: profileData}, {data: nicknameRows}, {data: theirNicknameForMeRows}] = await Promise.all([ supabaseClient.from("profiles").select("username, display_name, avatar_url").eq("id", targetId).single(), supabaseClient.from("nicknames").select("nickname").eq("setter_id", user.id).eq("target_id", targetId).order("created_at", {
    ascending: false
  }).limit(1), supabaseClient.from("nicknames").select("nickname").eq("setter_id", targetId).eq("target_id", user.id).order("created_at", {
    ascending: false
  }).limit(1) ]);
  const rawUsername = profileData?.username || "User";
  const profileName = profileData?.display_name || rawUsername;
  activeFluxNickname = nicknameRows?.[0]?.nickname || null;
  const displayName = activeFluxNickname || profileName;
  const actualUsername = profileData?.username || "Unknown user";
  document.getElementById("fluxProfileTabName").textContent = displayName;
  document.getElementById("fluxProfileTabUsername").textContent = actualUsername;
  const avatarEl = document.getElementById("fluxProfileTabAvatar");
  avatarEl.classList.remove("flux-avatar-editable");
  _fluxSetProfileTabAvatar(avatarEl, profileData?.avatar_url || null);
  const theirMutualAvatar = document.getElementById("fluxMutualTheirAvatar");
  if (theirMutualAvatar) setAvatarEl(theirMutualAvatar, profileData?.avatar_url || null);
  const theirMutualName = document.getElementById("fluxMutualTheirName");
  if (theirMutualName) theirMutualName.textContent = displayName;
  const theirMutualUsername = document.getElementById("fluxMutualTheirUsername");
  if (theirMutualUsername) theirMutualUsername.textContent = actualUsername;
  const myMutualAvatar = document.getElementById("fluxMutualMyAvatar");
  if (myMutualAvatar) setAvatarEl(myMutualAvatar, profile?.avatarUrl || null);
  const theirNicknameForMe = theirNicknameForMeRows?.[0]?.nickname || null;
  const myMutualName = document.getElementById("fluxMutualMyName");
  if (myMutualName) myMutualName.textContent = theirNicknameForMe || profile?.name || "You";
  const myMutualUsername = document.getElementById("fluxMutualMyUsername");
  if (myMutualUsername) myMutualUsername.textContent = profile?.username ? profile.username.replace(/^@/, "") : "you";
  hideNicknameEditor();
  _themePickerOpen = false;
  const picker = document.getElementById("fluxThemePicker");
  const chevron = document.getElementById("fluxThemeChevron");
  if (picker) picker.classList.remove("open");
  if (chevron) chevron.style.transform = "";
}

async function _fluxFetchGroupMembers(groupId) {
  const {data: memberRows} = await supabaseClient.from("flux_group_members").select("user_id, role").eq("group_id", groupId);
  const ids = (memberRows || []).map(r => r.user_id);
  if (!ids.length) return [];
  const {data: profileRows} = await supabaseClient.from("profiles").select("id, username, display_name, avatar_url").in("id", ids);
  const roleMap = new Map((memberRows || []).map(r => [ r.user_id, r.role ]));
  const profileMap = new Map((profileRows || []).map(p => [ p.id, p ]));
  return ids.map(id => {
    const p = profileMap.get(id) || {};
    return {
      id: id,
      role: roleMap.get(id) || "member",
      username: p.username || "user",
      name: p.display_name || p.username || "User",
      avatarUrl: p.avatar_url || null
    };
  });
}

function _fluxGroupDefaultMemberLabel(member, index) {
  const raw = String(member?.username || member?.name || "").replace(/^@/, "").trim();
  return raw || `user${index + 1}`;
}

async function _fluxBuildDefaultGroupName(groupId) {
  const {data: memberRows, error: memberError} = await supabaseClient.from("flux_group_members").select("user_id, created_at").eq("group_id", groupId).order("created_at", {
    ascending: true
  });
  if (memberError) throw memberError;
  const ids = (memberRows || []).map(row => row.user_id).filter(Boolean);
  if (!ids.length) return "Group";
  const {data: profiles, error: profileError} = await supabaseClient.from("profiles").select("id, username, display_name").in("id", ids);
  if (profileError) throw profileError;
  const profileMap = new Map((profiles || []).map(p => [ p.id, p ]));
  return ids.map((id, index) => _fluxGroupDefaultMemberLabel(profileMap.get(id), index)).join(", ").slice(0, 80) || "Group";
}

function _fluxApplyGroupNameLocally(groupId, name) {
  const value = name || "Group";
  fluxContacts.forEach(contact => {
    if (contact.groupId === groupId || contact.id === groupId) {
      contact.name = value;
      contact.realName = value;
      contact.username = value;
      contact.initials = value.charAt(0).toUpperCase();
    }
  });
  if (activeFluxId === groupId) {
    const topbarName = document.getElementById("fluxTopbarName");
    if (topbarName) topbarName.textContent = value;
    const fsName = document.getElementById("fluxFsName");
    if (fsName) fsName.textContent = value;
    if (activeFluxProfileTarget === groupId) {
      const mobName = document.getElementById("mobProfileSheetName");
      if (mobName) mobName.textContent = value;
    }
    if (_fluxConvIsGroup(groupId)) {
      _fluxUpdateGroupHeaderMembers(groupId);
    } else {
      const topbarUsername = document.getElementById("fluxTopbarUsername");
      if (topbarUsername) topbarUsername.textContent = value;
    }
  }
  try {
    buildFLUXConvList();
  } catch (e) {}
}

let _groupAvatarMenuOpen = false;

function openGroupAvatarMenu(e) {
  const groupId = activeFluxProfileTarget;
  if (!groupId || !_fluxConvIsGroup(groupId)) return;
  e.stopPropagation();
  closeAllFluxDropdowns(closeGroupAvatarMenu);
  const menu = document.getElementById("fluxGroupAvatarMenu");
  if (!menu) return;
  const contact = fluxContacts.find(c => c.id === groupId);
  const hasCustomAvatar = !!(contact && contact.avatarUrl);
  menu.innerHTML = "";
  const makeItem = (label, iconPath, onClick, opts) => {
    opts = opts || {};
    const btn = document.createElement("button");
    btn.className = "flux-conv-menu-item" + (opts.danger ? " danger" : "");
    if (opts.disabled) btn.disabled = true;
    btn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${iconPath}</svg> ${label}`;
    btn.onclick = ev => {
      ev.stopPropagation();
      closeGroupAvatarMenu();
      if (!opts.disabled) onClick();
    };
    return btn;
  };
  menu.appendChild(makeItem("Upload photo", '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>', () => document.getElementById("fluxGroupAvatarUpload").click()));
  menu.appendChild(makeItem("Remove photo", '<path d="M3 6h18"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>', () => removeGroupAvatar(groupId), {
    danger: true,
    disabled: !hasCustomAvatar
  }));
  const btn = e.currentTarget || e.target;
  const rect = btn.getBoundingClientRect ? btn.getBoundingClientRect() : {
    left: e.clientX,
    top: e.clientY,
    width: 0,
    height: 0
  };
  menu.style.display = "block";
  menu.classList.add("show");
  _groupAvatarMenuOpen = true;
  requestAnimationFrame(() => {
    const mw = menu.offsetWidth, mh = menu.offsetHeight;
    let left = rect.left + rect.width / 2 - mw / 2;
    if (left + mw > window.innerWidth - 8) left = window.innerWidth - mw - 8;
    if (left < 8) left = 8;
    let top = rect.bottom + 6;
    if (top + mh > window.innerHeight - 8) top = rect.top - mh - 6;
    menu.style.left = left + "px";
    menu.style.top = top + "px";
  });
}

function closeGroupAvatarMenu() {
  const menu = document.getElementById("fluxGroupAvatarMenu");
  if (!menu) return;
  menu.classList.remove("show");
  menu.style.display = "none";
  _groupAvatarMenuOpen = false;
}

document.addEventListener("click", e => {
  if (_groupAvatarMenuOpen && !document.getElementById("fluxGroupAvatarMenu").contains(e.target) && !e.target.closest("#fluxProfileTabAvatar")) closeGroupAvatarMenu();
});

let _gacGroupId = null;

function handleGroupAvatarUpload(e) {
  const file = e.target.files[0];
  e.target.value = "";
  if (!file) return;
  const groupId = activeFluxProfileTarget;
  if (!groupId || !_fluxConvIsGroup(groupId)) return;
  _gacGroupId = groupId;
  uploadCroppedGroupAvatar(file);
}

async function uploadCroppedGroupAvatar(file) {
  const groupId = _gacGroupId;
  if (!groupId) return;
  const {data: {user: user}} = await supabaseClient.auth.getUser();
  if (!user) return;
  const contact = fluxContacts.find(c => c.id === groupId);
  if (contact?.avatarUrl) {
    try {
      const path = contact.avatarUrl.split("/avatars/")[1]?.split("?")[0];
      if (path) await supabaseClient.storage.from("avatars").remove([ path ]);
    } catch (err) {}
  }
  const filePath = `group_${groupId}/avatar.png`;
  const {error: uploadError} = await supabaseClient.storage.from("avatars").upload(filePath, file, {
    upsert: true
  });
  if (uploadError) {
    alert("Upload failed: " + uploadError.message);
    return;
  }
  const {data: data} = supabaseClient.storage.from("avatars").getPublicUrl(filePath);
  const publicUrl = data.publicUrl + `?t=${Date.now()}`;
  const {error: rpcError} = await supabaseClient.rpc("set_flux_group_avatar", {
    p_group_id: groupId,
    p_avatar_url: publicUrl
  });
  if (rpcError) {
    alert("Failed to save group photo: " + rpcError.message);
    return;
  }
  _fluxApplyGroupAvatarLocally(groupId, publicUrl);
  try {
    const myName = (await supabaseClient.from("profiles").select("username").eq("id", user.id).single()).data?.username || "Someone";
    await _fluxPostSystemMessage(groupId, `${myName} changed the group icon.`);
  } catch (e) {
    console.warn("[FLUX] group-icon-change system message failed:", e.message || e);
  }
}

async function removeGroupAvatar(groupId) {
  if (!groupId) return;
  const contact = fluxContacts.find(c => c.id === groupId);
  if (contact?.avatarUrl) {
    try {
      const path = contact.avatarUrl.split("/avatars/")[1]?.split("?")[0];
      if (path) await supabaseClient.storage.from("avatars").remove([ path ]);
    } catch (err) {}
  }
  const {error: error} = await supabaseClient.rpc("set_flux_group_avatar", {
    p_group_id: groupId,
    p_avatar_url: null
  });
  if (error) {
    alert("Failed to remove group photo: " + error.message);
    return;
  }
  _fluxApplyGroupAvatarLocally(groupId, null);
  try {
    const {data: {user: user}} = await supabaseClient.auth.getUser();
    if (user) {
      const myName = (await supabaseClient.from("profiles").select("username").eq("id", user.id).single()).data?.username || "Someone";
      await _fluxPostSystemMessage(groupId, `${myName} removed the group icon.`);
    }
  } catch (e) {
    console.warn("[FLUX] group-icon-remove system message failed:", e.message || e);
  }
}

function _fluxApplyProfileLocally(userId, profileData) {
  if (!userId) return;
  if (currentUser?.id && userId === currentUser.id && profileData && Object.prototype.hasOwnProperty.call(profileData, "media_perm")) {
    window._cachedMediaPerm = profileData.media_perm !== false;
  }
  const avatarUrl = profileData?.avatar_url || null;
  const username = profileData?.username || "";
  const displayName = profileData?.display_name || username || "User";
  const dmContact = fluxContacts.find(c => c.id === userId && !c.isGroup);
  if (dmContact) {
    dmContact.avatarUrl = avatarUrl;
    if (username) dmContact.username = username;
    if (profileData?.display_name) dmContact.realName = displayName;
  }
  fluxContacts.forEach(contact => {
    if (!contact.isGroup || !contact.groupMembers?.includes(userId)) return;
    if (!contact.groupMemberProfiles) contact.groupMemberProfiles = {};
    const existing = contact.groupMemberProfiles[userId] || {};
    contact.groupMemberProfiles[userId] = {
      ...existing,
      username: username || existing.username || "",
      displayName: displayName || existing.displayName || "User",
      avatarUrl: avatarUrl
    };
    if (!contact.avatarUrl) {
      const pickedIds = _fluxPickTwoGroupMembers(contact.id, contact.groupMembers || []);
      contact.memberAvatars = pickedIds.map(id => {
        if (id === userId) return avatarUrl;
        const member = fluxContacts.find(c => c.id === id && !c.isGroup);
        return member?.avatarUrl || contact.groupMemberProfiles?.[id]?.avatarUrl || null;
      });
    }
  });
  document.querySelectorAll(".flux-group-avatar[data-sender-id]").forEach(el => {
    if (el.dataset.senderId !== userId) return;
    if (avatarUrl) {
      el.style.background = "transparent";
      el.classList.remove("default-avatar");
      el.innerHTML = "";
      const img = document.createElement("img");
      img.src = avatarUrl;
      img.alt = "";
      el.appendChild(img);
    } else {
      el.style.background = "#e8e8ec";
      el.classList.add("default-avatar");
      el.innerHTML = typeof DEFAULT_AVATAR_SVG !== "undefined" ? DEFAULT_AVATAR_SVG : "";
    }
  });
  if (activeFluxId === userId && !_fluxConvIsGroup(userId)) {
    const dmContactNow = fluxContacts.find(c => c.id === userId);
    const targets = [ document.getElementById("fluxTopbarAvatar"), document.getElementById("fluxFsAvatar"), document.getElementById("fluxProfileTabAvatar"), document.getElementById("mobProfileSheetAvatar") ];
    targets.forEach(el => {
      if (el) _fluxSetProfileTabAvatar(el, avatarUrl);
    });
  }
  fluxContacts.filter(c => c.isGroup && c.groupMembers?.includes(userId) && !c.avatarUrl).forEach(group => {
    if (activeFluxId === group.id) {
      const topbarAv = document.getElementById("fluxTopbarAvatar");
      const fsAv = document.getElementById("fluxFsAvatar");
      if (topbarAv) _fluxSetProfileTabAvatar(topbarAv, null, group.memberAvatars);
      if (fsAv) _fluxSetProfileTabAvatar(fsAv, null, group.memberAvatars);
    }
    if (activeFluxProfileTarget === group.id) {
      const panelAv = document.getElementById("fluxProfileTabAvatar");
      const mobAv = document.getElementById("mobProfileSheetAvatar");
      if (panelAv) _fluxSetProfileTabAvatar(panelAv, null, group.memberAvatars);
      if (mobAv) _fluxSetProfileTabAvatar(mobAv, null, group.memberAvatars);
    }
  });
  try {
    buildFLUXConvList();
  } catch (e) {}
}

function _fluxApplyGroupMetadataLocally(groupId, patch) {
  if (!groupId || !patch) return;
  if (Object.prototype.hasOwnProperty.call(patch, "name")) {
    _fluxApplyGroupNameLocally(groupId, patch.name);
  }
  if (Object.prototype.hasOwnProperty.call(patch, "avatar_url")) {
    _fluxApplyGroupAvatarLocally(groupId, patch.avatar_url);
  }
}

async function _fluxSetupMetadataRealtime(userId) {
  if (!userId || !supabaseClient) return;
  const remove = async key => {
    const ch = window[key];
    if (ch) {
      try {
        await supabaseClient.removeChannel(ch);
      } catch (e) {}
      window[key] = null;
    }
  };
  const profileState = window._fluxProfileMetaChannel?.state;
  if (!window._fluxProfileMetaChannel || profileState === "closed" || profileState === "errored") {
    await remove("_fluxProfileMetaChannel");
    window._fluxProfileMetaChannel = supabaseClient.channel(`profile-meta:${userId}`).on("postgres_changes", {
      event: "UPDATE",
      schema: "public",
      table: "profiles"
    }, payload => {
      const row = payload.new;
      if (!row?.id) return;
      _fluxApplyProfileLocally(row.id, row);
    }).subscribe();
  }
  const groupState = window._fluxGroupMetaChannel?.state;
  if (!window._fluxGroupMetaChannel || groupState === "closed" || groupState === "errored") {
    await remove("_fluxGroupMetaChannel");
    window._fluxGroupMetaChannel = supabaseClient.channel(`group-meta:${userId}`).on("postgres_changes", {
      event: "UPDATE",
      schema: "public",
      table: "flux_groups"
    }, payload => {
      const row = payload.new;
      if (!row?.id || !_fluxMyGroupIds?.has(row.id)) return;
      _fluxApplyGroupMetadataLocally(row.id, row);
    }).subscribe();
  }
}

function _fluxApplyGroupAvatarLocally(groupId, avatarUrl) {
  const contact = fluxContacts.find(c => c.id === groupId);
  if (contact) contact.avatarUrl = avatarUrl;
  if (activeFluxId === groupId) {
    const desktopAv = document.getElementById("fluxTopbarAvatar");
    if (desktopAv) _fluxSetProfileTabAvatar(desktopAv, avatarUrl, avatarUrl ? null : contact?.memberAvatars);
    const fsAv = document.getElementById("fluxFsAvatar");
    if (fsAv) _fluxSetProfileTabAvatar(fsAv, avatarUrl, avatarUrl ? null : contact?.memberAvatars);
    const mobAv = document.getElementById("mobProfileSheetAvatar");
    if (mobAv && activeFluxProfileTarget === groupId) _fluxSetProfileTabAvatar(mobAv, avatarUrl, avatarUrl ? null : contact?.memberAvatars);
  }
  if (activeFluxProfileTarget === groupId) {
    const panelAv = document.getElementById("fluxProfileTabAvatar");
    if (panelAv) _fluxSetProfileTabAvatar(panelAv, avatarUrl, avatarUrl ? null : contact?.memberAvatars);
  }
  try {
    buildFLUXConvList();
  } catch (e) {}
}

async function _fluxUpdateGroupHeaderMembers(groupId, members) {
  if (!groupId || !_fluxConvIsGroup(groupId)) return;
  try {
    const list = members || await _fluxFetchGroupMembers(groupId);
    const labels = list.map((member, index) => _fluxGroupDefaultMemberLabel(member, index)).filter(Boolean);
    const text = labels.join(", ") || "No members";
    const desktop = document.getElementById("fluxTopbarUsername");
    const mobile = document.getElementById("fluxFsUsername");
    if (desktop) desktop.textContent = text;
    if (mobile) mobile.textContent = text;
  } catch (e) {
    console.warn("[FLUX] failed to update group header members:", e.message || e);
  }
}

function showGroupNameEditor() {
  const groupId = activeFluxProfileTarget || activeFluxId;
  if (!groupId || !_fluxConvIsGroup(groupId)) return;
  const editor = document.getElementById("fluxGroupNameEditor");
  const input = document.getElementById("fluxGroupNameInput");
  const current = document.getElementById("fluxProfileTabName")?.textContent || "";
  if (!editor || !input) return;
  input.value = current === "Group" ? "" : current;
  editor.style.display = "flex";
  input.focus();
  input.select();
}

function hideGroupNameEditor() {
  const editor = document.getElementById("fluxGroupNameEditor");
  if (editor) editor.style.display = "none";
}

function groupNameInputKey(e) {
  if (e.key === "Enter") {
    e.preventDefault();
    commitGroupName();
  } else if (e.key === "Escape") {
    e.preventDefault();
    hideGroupNameEditor();
  }
}

async function commitGroupName() {
  const groupId = activeFluxProfileTarget || activeFluxId;
  const input = document.getElementById("fluxGroupNameInput");
  if (!groupId || !_fluxConvIsGroup(groupId) || !input) return;
  const name = input.value.trim().slice(0, 80);
  if (!name) return;
  const {error: error} = await supabaseClient.rpc("set_flux_group_name", {
    p_group_id: groupId,
    p_name: name,
    p_is_custom: true
  });
  if (error) {
    alert("Failed to change group name: " + error.message);
    return;
  }
  const nameEl = document.getElementById("fluxProfileTabName");
  if (nameEl) nameEl.textContent = name;
  _fluxApplyGroupNameLocally(groupId, name);
  hideGroupNameEditor();
  try {
    const {data: {user: user}} = await supabaseClient.auth.getUser();
    const myName = user ? (await supabaseClient.from("profiles").select("username").eq("id", user.id).single()).data?.username || "Someone" : "Someone";
    await _fluxPostSystemMessage(groupId, `${myName} changed the group name to "${name}".`);
  } catch (e) {
    console.warn("[FLUX] group-name-change system message failed:", e.message || e);
  }
}

function _fluxSetProfileTabAvatar(el, avatarUrl, dualAvatarUrls) {
  if (avatarUrl) {
    el.style.overflow = "hidden";
    el.style.borderRadius = "50%";
    el.style.background = "";
    setAvatarEl(el, avatarUrl);
  } else if (dualAvatarUrls) {
    el.classList.remove("default-avatar");
    el.style.overflow = "visible";
    el.style.borderRadius = "0";
    el.style.background = "transparent";
    el.innerHTML = buildDualAvatarHtml(dualAvatarUrls);
  } else {
    el.style.overflow = "hidden";
    el.style.borderRadius = "50%";
    el.style.background = "";
    setAvatarEl(el, null);
  }
}

async function loadGroupInfoSideTab(groupId, myUserId) {
  const titleEl = document.getElementById("fluxProfileTabTitle");
  if (titleEl) titleEl.textContent = "Group Info";
  const mutualSection = document.getElementById("fluxMutualSection");
  if (mutualSection) mutualSection.style.display = "none";
  const groupSection = document.getElementById("fluxGroupMembersSection");
  if (groupSection) groupSection.style.display = "";
  const editor = document.getElementById("fluxNicknameEditor");
  if (editor) editor.style.display = "none";
  hideGroupNameEditor();
  const groupNameRow = document.getElementById("fluxGroupNameRow");
  const groupNameEditBtn = document.getElementById("fluxGroupNameEditBtn");
  if (groupNameRow) groupNameRow.classList.add("is-group");
  const {data: groupData} = await supabaseClient.from("flux_groups").select("name, name_is_custom, avatar_url").eq("id", groupId).single();
  const groupName = groupData?.name || "Group";
  document.getElementById("fluxProfileTabName").textContent = groupName;
  const groupNameInput = document.getElementById("fluxGroupNameInput");
  if (groupNameInput) groupNameInput.value = groupName === "Group" ? "" : groupName;
  const members = await _fluxFetchGroupMembers(groupId);
  const canChangePfp = true;
  const canChangeName = true;
  if (groupNameEditBtn) groupNameEditBtn.style.display = "flex";
  const avatarEl = document.getElementById("fluxProfileTabAvatar");
  avatarEl.classList.toggle("flux-avatar-editable", canChangePfp);
  const pickedIds = _fluxPickTwoGroupMembers(groupId, members.map(m => m.id));
  const memberAvatars = pickedIds.map(id => (members.find(m => m.id === id) || {}).avatarUrl || null);
  _fluxSetProfileTabAvatar(avatarEl, groupData?.avatar_url || null, groupData?.avatar_url ? null : memberAvatars);
  const _groupContact = fluxContacts.find(c => c.id === groupId);
  if (_groupContact) {
    _groupContact.avatarUrl = groupData?.avatar_url || null;
    _groupContact.memberAvatars = memberAvatars;
    _groupContact.memberAvatars = memberAvatars;
  }
  const usernameEl = document.getElementById("fluxProfileTabUsername");
  if (usernameEl) usernameEl.textContent = `${members.length} member${members.length === 1 ? "" : "s"}`;
  const listEl = document.getElementById("fluxGroupMembersList");
  if (listEl) {
    listEl.innerHTML = members.map(m => {
      const avatar = m.avatarUrl ? `<img src="${escHtml(m.avatarUrl)}" alt="">` : DEFAULT_AVATAR_SVG;
      const nameLabel = m.id === myUserId ? "You" : escHtml(m.name);
      return `<div class="flux-mutual-row">\n        <div class="flux-mutual-avatar">${avatar}</div>\n        <div class="flux-mutual-name-col">\n          <div class="flux-mutual-name-wrap">\n            <div class="flux-mutual-name">${nameLabel}</div>\n          </div>\n          <div class="flux-mutual-username">@${escHtml((m.username || "").replace(/^@/, ""))}</div>\n        </div>\n      </div>`;
    }).join("");
  }
  _updateFluxDisappearingProfileButton(groupId);
  _themePickerOpen = false;
  const picker = document.getElementById("fluxThemePicker");
  const chevron = document.getElementById("fluxThemeChevron");
  if (picker) picker.classList.remove("open");
  if (chevron) chevron.style.transform = "";
}

async function openNicknameEditor() {
  if (!activeFluxProfileTarget) return;
  showNicknameEditor();
}

function showNicknameEditor() {
  const input = document.getElementById("fluxNicknameInput");
  const editor = document.getElementById("fluxNicknameEditor");
  const editBtn = document.getElementById("fluxNicknameEditBtn");
  if (!editor) return;
  if (input) input.value = activeFluxNickname || "";
  if (editBtn) editBtn.style.display = "none";
  editor.style.display = "flex";
  if (input) input.focus();
}

function hideNicknameEditor() {
  const editor = document.getElementById("fluxNicknameEditor");
  const editBtn = document.getElementById("fluxNicknameEditBtn");
  if (!editor) return;
  editor.style.display = "none";
  if (editBtn) editBtn.style.display = "flex";
}

function nicknameInputKey(e) {
  if (e.key === "Enter") {
    e.preventDefault();
    commitNickname();
  }
  if (e.key === "Escape") hideNicknameEditor();
}

async function commitNickname() {
  const input = document.getElementById("fluxNicknameInput");
  const val = (input?.value || "").trim();
  await saveNicknameForTarget(val);
  hideNicknameEditor();
}

async function clearNickname() {
  await saveNicknameForTarget("");
  hideNicknameEditor();
}

async function saveNicknameForTarget(nickname) {
  const {data: {user: user}} = await supabaseClient.auth.getUser();
  if (!user || !activeFluxProfileTarget) return;
  const contact = fluxContacts.find(c => c.id === activeFluxProfileTarget);
  const targetRealName = contact?.realName || contact?.name || "them";
  const myName = (await supabaseClient.from("profiles").select("username").eq("id", user.id).single()).data?.username || "You";
  let systemText = null;
  if (nickname === "") {
    await supabaseClient.from("nicknames").delete().eq("setter_id", user.id).eq("target_id", activeFluxProfileTarget);
    activeFluxNickname = null;
    systemText = `${myName} removed the nickname for ${targetRealName}.`;
  } else {
    await supabaseClient.from("nicknames").upsert([ {
      setter_id: user.id,
      target_id: activeFluxProfileTarget,
      nickname: nickname
    } ], {
      onConflict: "setter_id,target_id"
    });
    activeFluxNickname = nickname;
    systemText = `${myName} set the nickname for ${targetRealName} to "${nickname}".`;
  }
  if (systemText && activeFluxId === activeFluxProfileTarget) {
    await supabaseClient.from("messages").insert({
      sender_id: user.id,
      receiver_id: activeFluxProfileTarget,
      content: systemText,
      message_type: "system"
    });
  }
  if (contact) {
    contact.nickname = activeFluxNickname;
    contact.name = activeFluxNickname || contact.realName || contact.name;
    contact.initials = contact.name[0].toUpperCase();
    buildFLUXConvList();
    if (activeFluxId === activeFluxProfileTarget) {
      const topbarName = document.getElementById("fluxTopbarName");
      if (topbarName) topbarName.textContent = contact.name;
      const fsName = document.getElementById("fluxFsName");
      if (fsName) fsName.textContent = contact.name;
      const rawUser = contact.username || contact.realName || contact.name;
      const usernameEl = document.getElementById("fluxTopbarUsername");
      if (usernameEl) usernameEl.textContent = rawUser;
      const fsUsernameEl = document.getElementById("fluxFsUsername");
      if (fsUsernameEl) fsUsernameEl.textContent = "@" + rawUser;
      if (_fluxConvIsGroup(activeFluxId)) {
        _fluxUpdateGroupHeaderMembers(activeFluxId);
      }
    }
  }
  await loadNicknameSideTab(activeFluxProfileTarget);
}